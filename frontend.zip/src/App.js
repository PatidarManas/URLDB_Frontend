import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import Login from './Pages/Login';
import Signup from './Pages/Signup';
import Dashboard from './Pages/Dashboard';
import Instance from './Pages/Instance';
import User from './Pages/User';
import { useEffect, useState } from 'react';
import axios from 'axios';
function App() {
  const URL = "http://localhost:4000"

  const [loading,setloading] = useState(true);
  const [islogin,setlogin] = useState(false);
  
  async function isloginfunc(){
    const token = document.cookie;
      await axios.post(`${URL}/api/islogin`,{
        token
      }).then((res)=>{
        console.log(res);
        if(res.status==200){

          setlogin(true);
          setloading(false);
        }else if(res.status==204){
          setloading(false);
        }
      }).catch((error)=>{
        console.log(error)
      })
  }
  useEffect(() => {
    isloginfunc()
  }, [])
  
  return (
    <Router>
    <Routes>
      <Route path={"/login"} element={<>{loading?"Loading" : islogin ? <Dashboard/> :<Login/> }</>}/>
      <Route path={"/signup"} element={<>{loading?"Loading" : islogin ? <Dashboard/> :<Signup/> }</>}/>
      <Route path={"/dashboard"} element={<>{loading?"Loading" : islogin ? <Dashboard/> :<Login/> }</>}/>
      <Route path={"/instance/:instanceid"} element={<>{loading?"Loading" : islogin ? <Instance/> :<Login/> }</>}/>
      <Route path={"/instance/:instanceid/database/:databaseid"} element={<Instance/>}/>
      
      </Routes>
  </Router>
  );
}

export default App;
