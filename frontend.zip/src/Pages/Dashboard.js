import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
    const URL = "http://localhost:4000"

    const history = useNavigate();

    
    const [username,setusername] = useState("");
    const [password,setpassword] = useState("");
    const [instancecreateid,setinstancecreateid] = useState("");
    const [instances,setinstances] = useState([]);


    async function instancedataloder(){
        const token = document.cookie;
        axios.post(`${URL}/api/get-instances`,{
            token
        }).then((res)=>{
            if(res.status==200){
                setinstances(res.data);
            }
        }).catch((err)=>{
            alert(err);
        })
    }

    useEffect(() => {
      instancedataloder();
    }, [])
    

  async function logouthandler(e) {
    document.cookie = "token= ; expires = Thu, 01 Jan 1970 00:00:00 GMT";
    window.location.reload();
  }



  async function instancecreatehandler(e){
    e.preventDefault();

    const token = document.cookie;
    console.log(token);
    axios.post(`${URL}/api/create-instance`,{
        instanceId:instancecreateid,username,password,token
    }).then((res)=>{
        if(res.status==205){
            alert("Invalid Action! Please Re-login");
            document.cookie="";
            history('login');
        }else if(res.status==200){
            alert("Instance Created successfully");
            document.getElementById("createInstanceElementBox").style.display='none'
        }
    })
  }
  return (
    <div className="bg-gray-500 min-h-screen">
      <nav className="flex justify-between h-10 px-10 items-center align-center bg-blue-600 ">
        <a className="text-white">Admin Dashboard</a>
        <div>
          <button
            onClick={(e) => {
              logouthandler(e);
            }}
            className="text-red-500 text-xl font-bold"
          >
            Logout
          </button>
        </div>
      </nav>
      <div id="createInstanceElementBox" className="hidden fixed top-0  justify-center">
        <button onClick={()=>{document.getElementById("createInstanceElementBox").style.display='none'}} className="w-screen h-screen bg-black opacity-50 z-10"></button>
        <div className="w-96 min-h-96 bg-white rounded-xl fixed top-0 mt-40 z-50 self-center flex flex-col items-center p-10 gap-5">
          <div className="w-full">
            <label
              for="Id"
              class="block mb-2 text-sm font-medium text-gray-900 "
            >
              Instance Id
            </label>
            <input
              onChange={(e) => setinstancecreateid(e.target.value)}
              type="string"
              name="Id"
              id="Id"
              class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5"
              placeholder="IN05565X52"
              required=""
            />
          </div>
          <div className="w-full">
            <label
              for="username"
              class="block mb-2 text-sm font-medium text-gray-900"
            >
              Your Username
            </label>
            <input
              onChange={(e) => setusername(e.target.value)}
              type="string"
              name="username"
              id="username"
              class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 "
              placeholder="name@company.com"
              required=""
            />
          </div>
          <div className="w-full">
            <label
              for="Password"
              class="block mb-2 text-sm font-medium text-gray-900"
            >
              Your Passwrod
            </label>
            <input
              onChange={(e) => setpassword(e.target.value)}
              type="Password"
              name="Password"
              id="Password"
              class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5"
              placeholder="********"
              required=""
            />
          </div>
          <button onClick={(e)=>{instancecreatehandler(e)}} className="text-xl font-semibold rounded-lg bg-blue-600 text-white px-4 py-1 ">Submit</button>
        </div>
      </div>
      <div className="px-40 pt-20 pb-20">
        <button onClick={()=>{document.getElementById("createInstanceElementBox").style.display='flex'}} className=" test-2xl px-2 py-1 font-semibold bg-blue-500 rounded-lg text-white">
          Create Instance
        </button>
        <h1 className="text-2xl mt-10 pl-2 text-white font-mono">
          Instances Connected -
        </h1>
        <div className="flex  flex-wrap mt-5 mx-5 gap-10">
          {instances.length==0 ? " Loading" :instances.map((value,index)=>{
return(
          <button onClick={()=>{}} className="w-60 h-60 bg-slate-600 rounded-xl p-5 flex flex-col items-center">
            <h1 className="text-2xl font-mono text-white text-center">
              {value.instanceId}
            </h1>
            <h2 className="text-2xl font-mono text-gray-400 text-center mt-5">
             {value.occupiedSpace} Mb Occupied
            </h2>
            <h2 className="text-2xl font-mono text-gray-400 text-center mt-1">
              {value.databases.length} Databases
            </h2>
            <h3 className="text-xl bg-blue-500 rounded-lg px-2 py-1 text-white hover:text-blue-400 hover:bg-white mt-5">
              See More
            </h3>
          </button>)
          })}
         
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
